
$(function(){
    $('.fit-picture').each(function() {
        var num = Math.floor(Math.random() * 20 + 1),
            img = $(this);
            if (num>=10) {
                img.attr('src', 'https://cloudcomputing-i-pro.s3.amazonaws.com/images/im' + num + '.jpg');
                
            }else{
                img.attr('src', 'https://cloudcomputing-i-pro.s3.amazonaws.com/images/im0' + num + '.jpg');
            }
        img.attr('alt', 'Src: '+img.attr('src'));
    });
    
});

function recordCheckBoxes() {
    let box1 = document.getElementById('check1').checked;
    let img1 = document.getElementById('img1').src;
    let box2 = document.getElementById('check2').checked;
    let img2 = document.getElementById('img2').src;
    let box3 = document.getElementById('check3').checked;
    let img3 = document.getElementById('img3').src;
    let box4 = document.getElementById('check4').checked;
    let img4 = document.getElementById('img4').src;
    console.log(img1,box1);
    console.log(img2,box2);
    console.log(img3,box3);
    console.log(img4,box4);
    alert("Votes Submitted");
    var blob = new Blob([img1,"\n",box1,"\n",img2,"\n",box2,"\n",img3,"\n",box3,"\n",img4,"\n",box4],
                { type: "text/plain;charset=utf-8" });
                saveAs(blob, "data.txt");
    //send txt file?
  }

function reload(){
    window.location.reload();
}

function upload(){
 //TODO + count nb d'images en tout?
}